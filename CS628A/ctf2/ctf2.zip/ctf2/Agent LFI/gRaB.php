
    <?php
    $key = a040ecf743f127508aaac0366b676101;

    $flag = 'cs628a{' . $key . '}';

    ?>
    