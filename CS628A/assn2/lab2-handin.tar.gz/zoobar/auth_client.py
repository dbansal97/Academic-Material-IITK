from debug import *
from zoodb import *
import rpclib

# Excercise 5
def login(username, password):
    sock = '/authsvc/sock'
    with rpclib.client_connect(sock) as c:
        return c.call('login', username = username, password = password)

def register(username, password):
    sock = '/authsvc/sock'
    with rpclib.client_connect(sock) as c:
        return c.call('register', username = username, password = password)

def check_token(username, token):
    sock = '/authsvc/sock'
    with rpclib.client_connect(sock) as c:
        return c.call('check_token', username = username, token = token)
